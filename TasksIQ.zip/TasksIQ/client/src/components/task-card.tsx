import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import TaskDetailsModal from "./task-details-modal";
import type { TaskWithDetails } from "@/types";

interface TaskCardProps {
  task: TaskWithDetails;
}

export default function TaskCard({ task }: TaskCardProps) {
  const [showDetails, setShowDetails] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const acceptTaskMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("PUT", `/api/tasks/${task.id}`, {
        status: "accepted"
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/tasks'] });
      queryClient.invalidateQueries({ queryKey: ['/api/dashboard/stats'] });
      toast({
        title: "Task Accepted",
        description: "You have successfully accepted this task! 🎉",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to accept task",
        variant: "destructive",
      });
    },
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending':
        return 'bg-orange-100 text-status-pending';
      case 'accepted':
      case 'in_progress':
        return 'bg-blue-100 text-status-progress';
      case 'completed':
        return 'bg-green-100 text-status-completed';
      case 'cancelled':
        return 'bg-red-100 text-status-cancelled';
      default:
        return 'bg-gray-100 text-gray-600';
    }
  };

  const formatDueDate = (dueDate: string | null) => {
    if (!dueDate) return 'No due date';
    
    const date = new Date(dueDate);
    const now = new Date();
    const isToday = date.toDateString() === now.toDateString();
    const isTomorrow = date.toDateString() === new Date(now.getTime() + 24 * 60 * 60 * 1000).toDateString();
    
    if (isToday) {
      return `Today ${date.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true })}`;
    } else if (isTomorrow) {
      return `Tomorrow ${date.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true })}`;
    } else {
      return date.toLocaleDateString('en-US', { 
        month: 'short', 
        day: 'numeric',
        hour: 'numeric', 
        minute: '2-digit', 
        hour12: true 
      });
    }
  };

  return (
    <>
      <Card className="bg-white rounded-2xl shadow-lg" data-testid={`task-card-${task.id}`}>
        <CardContent className="p-4">
          <div className="flex items-start justify-between mb-3">
            <div className="flex-1">
              <h3 className="font-semibold text-gray-800 mb-1" data-testid={`task-title-${task.id}`}>
                {task.title}
              </h3>
              <p className="text-sm text-gray-600 mb-2" data-testid={`task-description-${task.id}`}>
                {task.description}
              </p>
              <div className="flex items-center space-x-4 text-xs text-gray-500">
                <span>
                  <i className="fas fa-calendar mr-1"></i>
                  Due: <span data-testid={`task-due-date-${task.id}`}>{formatDueDate(task.dueDate)}</span>
                </span>
                <span>
                  <i className="fas fa-user mr-1"></i>
                  From: <span data-testid={`task-assigned-by-${task.id}`}>{task.assignedBy.name}</span>
                </span>
              </div>
            </div>
            <Badge 
              className={`px-3 py-1 text-xs font-medium rounded-full ${getStatusColor(task.status)}`}
              data-testid={`task-status-${task.id}`}
            >
              {task.status === 'in_progress' ? 'In Progress' : 
               task.status.charAt(0).toUpperCase() + task.status.slice(1)}
            </Badge>
          </div>
          <div className="flex space-x-2">
            {task.status === 'pending' && (
              <Button
                onClick={() => acceptTaskMutation.mutate()}
                disabled={acceptTaskMutation.isPending}
                className="flex-1 bg-primary-green text-white py-2 rounded-lg text-sm font-medium hover:bg-green-600 transition-colors"
                data-testid={`button-accept-task-${task.id}`}
              >
                {acceptTaskMutation.isPending ? "Accepting..." : "Accept"}
              </Button>
            )}
            {task.status === 'in_progress' && (
              <Button
                onClick={() => setShowDetails(true)}
                className="flex-1 bg-primary-blue text-white py-2 rounded-lg text-sm font-medium hover:bg-blue-600 transition-colors"
                data-testid={`button-update-status-${task.id}`}
              >
                Update Status
              </Button>
            )}
            <Button
              onClick={() => setShowDetails(true)}
              variant="outline"
              className="flex-1 bg-gray-100 text-gray-700 py-2 rounded-lg text-sm font-medium hover:bg-gray-200 transition-colors"
              data-testid={`button-view-details-${task.id}`}
            >
              View Details
            </Button>
          </div>
        </CardContent>
      </Card>

      {showDetails && (
        <TaskDetailsModal
          task={task}
          isOpen={showDetails}
          onClose={() => setShowDetails(false)}
        />
      )}
    </>
  );
}
