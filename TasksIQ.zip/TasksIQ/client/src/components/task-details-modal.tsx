import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { useAuthStore } from "@/lib/auth";
import { apiRequest } from "@/lib/queryClient";
import type { TaskWithDetails, TaskStatus } from "@/types";

interface TaskDetailsModalProps {
  task: TaskWithDetails;
  isOpen: boolean;
  onClose: () => void;
}

export default function TaskDetailsModal({ task, isOpen, onClose }: TaskDetailsModalProps) {
  const [selectedStatus, setSelectedStatus] = useState<TaskStatus | null>(null);
  const [comment, setComment] = useState("");
  const { toast } = useToast();
  const { user } = useAuthStore();
  const queryClient = useQueryClient();

  const updateTaskMutation = useMutation({
    mutationFn: async (data: { status: TaskStatus; comment: string }) => {
      // First update task status
      const taskResponse = await apiRequest("PUT", `/api/tasks/${task.id}`, {
        status: data.status
      });
      
      // Then add comment
      if (data.comment.trim()) {
        await apiRequest("POST", `/api/tasks/${task.id}/comments`, {
          userId: user?.id,
          comment: data.comment.trim()
        });
      }
      
      return taskResponse.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/tasks'] });
      queryClient.invalidateQueries({ queryKey: ['/api/dashboard/stats'] });
      toast({
        title: "Status Updated",
        description: "Task status has been updated successfully! ✅",
      });
      onClose();
      setSelectedStatus(null);
      setComment("");
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update task status",
        variant: "destructive",
      });
    },
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending':
        return 'bg-orange-100 text-status-pending';
      case 'accepted':
      case 'in_progress':
        return 'bg-blue-100 text-status-progress';
      case 'completed':
        return 'bg-green-100 text-status-completed';
      case 'cancelled':
        return 'bg-red-100 text-status-cancelled';
      default:
        return 'bg-gray-100 text-gray-600';
    }
  };

  const formatDueDate = (dueDate: string | null) => {
    if (!dueDate) return 'No due date';
    
    const date = new Date(dueDate);
    const now = new Date();
    const isToday = date.toDateString() === now.toDateString();
    
    if (isToday) {
      return `Today, ${date.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true })}`;
    } else {
      return date.toLocaleDateString('en-US', { 
        month: 'short', 
        day: 'numeric',
        hour: 'numeric', 
        minute: '2-digit', 
        hour12: true 
      });
    }
  };

  const getTimeRemaining = (dueDate: string | null) => {
    if (!dueDate) return null;
    
    const due = new Date(dueDate);
    const now = new Date();
    const diffMs = due.getTime() - now.getTime();
    
    if (diffMs <= 0) return 'Overdue';
    
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
    const diffMinutes = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));
    
    if (diffHours > 0) {
      return `${diffHours}h ${diffMinutes}m remaining`;
    } else {
      return `${diffMinutes}m remaining`;
    }
  };

  const handleStatusUpdate = () => {
    if (!selectedStatus) {
      toast({
        title: "Error",
        description: "Please select a status",
        variant: "destructive",
      });
      return;
    }

    if (!comment.trim()) {
      toast({
        title: "Error",
        description: "Comment is required for status updates",
        variant: "destructive",
      });
      return;
    }

    updateTaskMutation.mutate({
      status: selectedStatus,
      comment: comment.trim()
    });
  };

  const statusOptions = [
    { value: 'in_progress' as TaskStatus, label: 'In Progress', color: 'status-progress' },
    { value: 'completed' as TaskStatus, label: 'Completed', color: 'status-completed' },
    { value: 'cancelled' as TaskStatus, label: 'Cancelled', color: 'status-cancelled' }
  ];

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md mx-auto rounded-t-3xl animate-slide-up" data-testid="modal-task-details">
        <DialogHeader className="flex items-center justify-between mb-6">
          <DialogTitle className="text-xl font-bold text-gray-800" data-testid="text-task-details-title">
            Task Details
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Task Header */}
          <div>
            <h3 className="text-lg font-semibold text-gray-800 mb-2" data-testid="text-task-detail-title">
              {task.title}
            </h3>
            <div className="flex items-center space-x-2 mb-4">
              <Badge 
                className={`px-3 py-1 text-sm font-medium rounded-full ${getStatusColor(task.status)}`}
                data-testid="badge-task-status"
              >
                {task.status === 'in_progress' ? 'In Progress' : 
                 task.status.charAt(0).toUpperCase() + task.status.slice(1)}
              </Badge>
              {task.dueDate && (
                <div className="flex items-center text-sm text-gray-600">
                  <i className="fas fa-clock mr-1"></i>
                  <span data-testid="text-time-remaining">{getTimeRemaining(task.dueDate)}</span>
                </div>
              )}
            </div>
          </div>

          {/* Task Info */}
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
              <p className="text-gray-600" data-testid="text-task-detail-description">
                {task.description || 'No description provided'}
              </p>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Assigned by</label>
                <p className="text-gray-600" data-testid="text-task-assigned-by-detail">
                  {task.assignedBy.name}
                </p>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Due Date</label>
                <p className="text-gray-600" data-testid="text-task-due-date-detail">
                  {formatDueDate(task.dueDate)}
                </p>
              </div>
            </div>
          </div>

          {/* Status Update Section - Only show for team members on accepted/in_progress tasks */}
          {user?.role === 'team_member' && ['accepted', 'in_progress'].includes(task.status) && (
            <div className="border-t pt-6">
              <label className="block text-sm font-medium text-gray-700 mb-2">Update Status</label>
              <div className="grid grid-cols-3 gap-2 mb-4">
                {statusOptions.map((option) => (
                  <button
                    key={option.value}
                    onClick={() => setSelectedStatus(option.value)}
                    className={`flex flex-col items-center space-y-1 p-3 border-2 rounded-xl transition-colors ${
                      selectedStatus === option.value 
                        ? `border-${option.color}` 
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                    data-testid={`button-status-${option.value}`}
                  >
                    <div className={`w-3 h-3 bg-${option.color} rounded-full`}></div>
                    <span className="text-xs font-medium">{option.label}</span>
                  </button>
                ))}
              </div>

              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Comment <span className="text-red-500">*</span>
                </label>
                <Textarea
                  placeholder="Add a comment about your progress..."
                  rows={3}
                  value={comment}
                  onChange={(e) => setComment(e.target.value)}
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-primary-blue focus:border-transparent resize-none"
                  data-testid="textarea-status-comment"
                />
              </div>

              <Button
                onClick={handleStatusUpdate}
                disabled={updateTaskMutation.isPending || !selectedStatus || !comment.trim()}
                className="w-full bg-primary-blue text-white py-3 rounded-xl font-semibold hover:bg-blue-600 transition-colors"
                data-testid="button-update-task-status"
              >
                {updateTaskMutation.isPending ? "Updating..." : "Update Status"}
              </Button>
            </div>
          )}

          {/* Comments Section */}
          {task.comments && task.comments.length > 0 && (
            <div className="border-t pt-6">
              <h4 className="text-sm font-medium text-gray-700 mb-3">Comments</h4>
              <div className="space-y-2 max-h-32 overflow-y-auto custom-scrollbar">
                {task.comments.map((taskComment) => (
                  <div key={taskComment.id} className="bg-gray-50 rounded-lg p-3">
                    <p className="text-sm text-gray-600" data-testid={`text-comment-${taskComment.id}`}>
                      {taskComment.comment}
                    </p>
                    <p className="text-xs text-gray-400 mt-1">
                      {new Date(taskComment.createdAt).toLocaleDateString('en-US', {
                        month: 'short',
                        day: 'numeric',
                        hour: 'numeric',
                        minute: '2-digit',
                        hour12: true
                      })}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
