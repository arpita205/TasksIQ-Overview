import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { useAuthStore } from "@/lib/auth";
import { apiRequest } from "@/lib/queryClient";

interface CreateTaskModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function CreateTaskModal({ isOpen, onClose }: CreateTaskModalProps) {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [assignedToId, setAssignedToId] = useState("");
  const [dueDate, setDueDate] = useState("");
  const [dueTime, setDueTime] = useState("");
  
  const { toast } = useToast();
  const { user } = useAuthStore();
  const queryClient = useQueryClient();

  // Get team members for assignment dropdown
  const { data: teamMembers = [] } = useQuery({
    queryKey: ['/api/projects/project-1/members'], // Using hardcoded project for demo
    queryFn: async () => {
      const response = await fetch('/api/projects/project-1/members');
      return response.json();
    },
  });

  const createTaskMutation = useMutation({
    mutationFn: async (taskData: any) => {
      const response = await apiRequest("POST", "/api/tasks", taskData);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/tasks'] });
      queryClient.invalidateQueries({ queryKey: ['/api/dashboard/stats'] });
      toast({
        title: "Task Created",
        description: "Task has been successfully assigned! 🎉",
      });
      onClose();
      resetForm();
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to create task",
        variant: "destructive",
      });
    },
  });

  const resetForm = () => {
    setTitle("");
    setDescription("");
    setAssignedToId("");
    setDueDate("");
    setDueTime("");
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!title.trim() || !assignedToId) {
      toast({
        title: "Error",
        description: "Please fill in required fields",
        variant: "destructive",
      });
      return;
    }

    let dueDateTime = null;
    if (dueDate && dueTime) {
      dueDateTime = new Date(`${dueDate}T${dueTime}`);
    } else if (dueDate) {
      dueDateTime = new Date(`${dueDate}T23:59`);
    }

    createTaskMutation.mutate({
      title: title.trim(),
      description: description.trim(),
      assignedById: user?.id,
      assignedToId,
      projectId: 'project-1', // Using hardcoded project for demo
      dueDate: dueDateTime,
      status: 'pending',
    });
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md mx-auto rounded-t-3xl animate-slide-up" data-testid="modal-create-task">
        <DialogHeader className="flex items-center justify-between mb-6">
          <DialogTitle className="text-xl font-bold text-gray-800" data-testid="text-create-task-title">
            Create New Task
          </DialogTitle>
        </DialogHeader>

        {/* Step Progress */}
        <div className="flex items-center mb-6">
          <div className="flex items-center space-x-2 text-sm">
            <span className="w-6 h-6 bg-primary-blue text-white rounded-full flex items-center justify-center text-xs">1</span>
            <span className="text-primary-blue font-medium">Details</span>
            <i className="fas fa-chevron-right text-gray-400"></i>
            <span className="w-6 h-6 bg-gray-200 text-gray-600 rounded-full flex items-center justify-center text-xs">2</span>
            <span className="text-gray-600">Assign</span>
            <i className="fas fa-chevron-right text-gray-400"></i>
            <span className="w-6 h-6 bg-gray-200 text-gray-600 rounded-full flex items-center justify-center text-xs">3</span>
            <span className="text-gray-600">Schedule</span>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Task Title <span className="text-red-500">*</span>
            </label>
            <Input
              type="text"
              placeholder="Enter task title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-primary-blue focus:border-transparent"
              data-testid="input-task-title"
              required
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Description</label>
            <Textarea
              placeholder="Describe the task..."
              rows={3}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-primary-blue focus:border-transparent resize-none"
              data-testid="textarea-task-description"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Assign to <span className="text-red-500">*</span>
            </label>
            <Select value={assignedToId} onValueChange={setAssignedToId} required>
              <SelectTrigger 
                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-primary-blue focus:border-transparent"
                data-testid="select-assign-to"
              >
                <SelectValue placeholder="Select team member" />
              </SelectTrigger>
              <SelectContent>
                {teamMembers.map((member: any) => (
                  <SelectItem key={member.user.id} value={member.user.id}>
                    {member.user.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Due Date</label>
              <Input
                type="date"
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-primary-blue focus:border-transparent"
                data-testid="input-due-date"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Due Time</label>
              <Input
                type="time"
                value={dueTime}
                onChange={(e) => setDueTime(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-primary-blue focus:border-transparent"
                data-testid="input-due-time"
              />
            </div>
          </div>

          <Button
            type="submit"
            disabled={createTaskMutation.isPending}
            className="w-full bg-accent-orange text-white py-3 rounded-xl font-semibold hover:bg-orange-600 transition-colors"
            data-testid="button-assign-task"
          >
            {createTaskMutation.isPending ? "Creating..." : "Assign Task"}
          </Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}
