import { useLocation } from "wouter";

interface BottomNavigationProps {
  userRole: 'admin' | 'team_member';
}

export default function BottomNavigation({ userRole }: BottomNavigationProps) {
  const [location, setLocation] = useLocation();

  const adminNavItems = [
    {
      id: 'dashboard',
      icon: 'fas fa-home',
      label: 'Dashboard',
      path: '/admin-dashboard',
    },
    {
      id: 'projects',
      icon: 'fas fa-folder',
      label: 'Projects',
      path: '/admin-dashboard', // For now, same as dashboard
    },
    {
      id: 'add-task',
      icon: 'fas fa-plus-circle',
      label: 'Add Task',
      path: '/admin-dashboard', // Handled by modal
    },
    {
      id: 'profile',
      icon: 'fas fa-user',
      label: 'Profile',
      path: '/profile',
    },
  ];

  const teamNavItems = [
    {
      id: 'tasks',
      icon: 'fas fa-tasks',
      label: 'Tasks',
      path: '/team-dashboard',
    },
    {
      id: 'notifications',
      icon: 'fas fa-bell',
      label: 'Notifications',
      path: '/team-dashboard', // For now, same as dashboard
    },
    {
      id: 'profile',
      icon: 'fas fa-user',
      label: 'Profile',
      path: '/profile',
    },
  ];

  const navItems = userRole === 'admin' ? adminNavItems : teamNavItems;

  const isActivePath = (itemPath: string) => {
    if (itemPath === '/profile') {
      return location === '/profile';
    }
    
    if (userRole === 'admin') {
      return location === '/admin-dashboard' || location === '/';
    } else {
      return location === '/team-dashboard' || location === '/';
    }
  };

  const handleNavClick = (item: typeof navItems[0]) => {
    if (item.id === 'add-task') {
      // This will be handled by the parent component's create task modal
      return;
    }
    setLocation(item.path);
  };

  return (
    <div className="fixed bottom-0 left-1/2 transform -translate-x-1/2 w-full max-w-md bg-white border-t border-gray-200 px-6 py-3 z-50">
      <div className="flex justify-around">
        {navItems.map((item) => {
          const isActive = isActivePath(item.path);
          
          return (
            <button
              key={item.id}
              onClick={() => handleNavClick(item)}
              className={`flex flex-col items-center space-y-1 transition-colors ${
                isActive 
                  ? userRole === 'admin' 
                    ? 'text-primary-blue' 
                    : 'text-primary-green'
                  : 'text-gray-400 hover:text-gray-600'
              }`}
              data-testid={`nav-${item.id}`}
            >
              <i className={`${item.icon} text-lg`}></i>
              <span className="text-xs">{item.label}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
