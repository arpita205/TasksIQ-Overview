export interface AuthState {
  user: any | null;
  isAuthenticated: boolean;
  tempEmail: string;
  isOTPVerified: boolean;
}

export interface DashboardStats {
  projectCount?: number;
  taskStats: {
    pending: number;
    progress: number;
    completed: number;
    cancelled: number;
  };
  totalTasks?: number;
}

export type TaskStatus = 'pending' | 'accepted' | 'in_progress' | 'completed' | 'cancelled';

export interface TaskStatusUpdate {
  status: TaskStatus;
  comment: string;
}
