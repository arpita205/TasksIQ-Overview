import { useState } from "react";
import { useLocation } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { useAuthStore } from "@/lib/auth";

export default function ProfileScreen() {
  const [, setLocation] = useLocation();
  const { user, logout } = useAuthStore();
  const [notifications, setNotifications] = useState(true);
  const [darkMode, setDarkMode] = useState(false);

  if (!user) {
    setLocation('/login');
    return null;
  }

  const goBackToDashboard = () => {
    if (user.role === 'admin') {
      setLocation('/admin-dashboard');
    } else {
      setLocation('/team-dashboard');
    }
  };

  const handleLogout = () => {
    logout();
    setLocation('/login');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white px-6 py-4 border-b border-gray-200">
        <div className="flex items-center space-x-3">
          <button 
            onClick={goBackToDashboard}
            className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center"
            data-testid="button-back"
          >
            <i className="fas fa-arrow-left text-gray-600"></i>
          </button>
          <h1 className="text-xl font-bold text-gray-800" data-testid="text-profile-title">Profile</h1>
        </div>
      </div>

      <div className="px-6 py-6 space-y-6">
        {/* Profile Info */}
        <Card className="bg-white rounded-2xl shadow-lg">
          <CardContent className="p-6">
            <div className="flex items-center space-x-4 mb-6">
              <div className="w-16 h-16 bg-gradient-to-br from-primary-blue to-purple-600 rounded-full flex items-center justify-center">
                <span className="text-white text-xl font-bold" data-testid="text-profile-initials">
                  {user.name.split(' ').map(n => n[0]).join('')}
                </span>
              </div>
              <div className="flex-1">
                <h3 className="text-lg font-semibold text-gray-800" data-testid="text-profile-name">
                  {user.name}
                </h3>
                <p className="text-gray-600 capitalize" data-testid="text-profile-role">
                  {user.role.replace('_', ' ')}
                </p>
              </div>
              <button className="text-primary-blue" data-testid="button-edit-profile">
                <i className="fas fa-edit"></i>
              </button>
            </div>

            <div className="space-y-3">
              <div className="flex items-center space-x-3">
                <i className="fas fa-envelope w-5 text-gray-400"></i>
                <span className="text-gray-600" data-testid="text-profile-email">{user.email}</span>
              </div>
              {user.phone && (
                <div className="flex items-center space-x-3">
                  <i className="fas fa-phone w-5 text-gray-400"></i>
                  <span className="text-gray-600" data-testid="text-profile-phone">{user.phone}</span>
                </div>
              )}
              <div className="flex items-center space-x-3">
                <i className="fas fa-calendar w-5 text-gray-400"></i>
                <span className="text-gray-600" data-testid="text-profile-joined">
                  Joined {new Date(user.createdAt).toLocaleDateString('en-US', { month: 'short', year: 'numeric' })}
                </span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Settings */}
        <Card className="bg-white rounded-2xl shadow-lg">
          <CardContent className="p-6">
            <h3 className="text-lg font-semibold text-gray-800 mb-4" data-testid="text-settings-title">Settings</h3>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <i className="fas fa-bell w-5 text-gray-400"></i>
                  <span className="text-gray-700" data-testid="text-notifications-setting">Notifications</span>
                </div>
                <Switch 
                  checked={notifications}
                  onCheckedChange={setNotifications}
                  data-testid="switch-notifications"
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <i className="fas fa-moon w-5 text-gray-400"></i>
                  <span className="text-gray-700" data-testid="text-dark-mode-setting">Dark Mode</span>
                </div>
                <Switch 
                  checked={darkMode}
                  onCheckedChange={setDarkMode}
                  data-testid="switch-dark-mode"
                />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Help & Support */}
        <Card className="bg-white rounded-2xl shadow-lg">
          <CardContent className="p-6">
            <h3 className="text-lg font-semibold text-gray-800 mb-4" data-testid="text-help-title">Help & Support</h3>
            <div className="space-y-3">
              <button className="w-full flex items-center space-x-3 p-3 text-left hover:bg-gray-50 rounded-xl transition-colors"
                data-testid="button-faq"
              >
                <i className="fas fa-question-circle w-5 text-gray-400"></i>
                <span className="text-gray-700">FAQ</span>
                <i className="fas fa-chevron-right ml-auto text-gray-400"></i>
              </button>
              <button className="w-full flex items-center space-x-3 p-3 text-left hover:bg-gray-50 rounded-xl transition-colors"
                data-testid="button-contact-support"
              >
                <i className="fas fa-headset w-5 text-gray-400"></i>
                <span className="text-gray-700">Contact Support</span>
                <i className="fas fa-chevron-right ml-auto text-gray-400"></i>
              </button>
            </div>
          </CardContent>
        </Card>

        {/* Logout */}
        <Button
          onClick={handleLogout}
          className="w-full bg-red-50 text-red-600 py-3 rounded-xl font-semibold hover:bg-red-100 transition-colors"
          data-testid="button-logout"
        >
          <i className="fas fa-sign-out-alt mr-2"></i>
          Logout
        </Button>
      </div>
    </div>
  );
}
