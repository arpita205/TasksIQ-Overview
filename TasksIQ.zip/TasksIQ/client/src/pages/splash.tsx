import { useEffect } from "react";
import { useLocation } from "wouter";
import { useAuthStore } from "@/lib/auth";

export default function SplashScreen() {
  const [, setLocation] = useLocation();
  const { user } = useAuthStore();

  useEffect(() => {
    const timer = setTimeout(() => {
      if (user) {
        // User is logged in, redirect to appropriate dashboard
        if (user.role === 'admin') {
          setLocation('/admin-dashboard');
        } else {
          setLocation('/team-dashboard');
        }
      } else {
        // No user, go to login
        setLocation('/login');
      }
    }, 3000);

    return () => clearTimeout(timer);
  }, [setLocation, user]);

  return (
    <div className="fixed inset-0 bg-gradient-primary flex flex-col items-center justify-center z-50">
      <div className="text-center text-white animate-fade-in">
        <div className="mb-8">
          <i className="fas fa-tasks text-6xl mb-4 animate-pulse-slow"></i>
          <h1 className="text-3xl font-bold mb-2" data-testid="app-title">TasksIQ</h1>
          <p className="text-lg opacity-90" data-testid="app-tagline">Smart Tasking. Smarter Teams.</p>
        </div>
        <div className="w-48 bg-white/20 rounded-full h-2 overflow-hidden">
          <div 
            className="h-full bg-white rounded-full animate-pulse transition-all duration-1000"
            style={{ width: '75%' }}
            data-testid="progress-bar"
          ></div>
        </div>
      </div>
    </div>
  );
}
