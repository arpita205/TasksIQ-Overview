import { useState } from "react";
import { useLocation } from "wouter";
import { useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { useAuthStore } from "@/lib/auth";
import { apiRequest } from "@/lib/queryClient";

export default function LoginScreen() {
  const [emailOrPhone, setEmailOrPhone] = useState("");
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const { setTempEmail } = useAuthStore();

  const sendOTPMutation = useMutation({
    mutationFn: async (data: { emailOrPhone: string }) => {
      const response = await apiRequest("POST", "/api/auth/send-otp", data);
      return response.json();
    },
    onSuccess: () => {
      setTempEmail(emailOrPhone);
      toast({
        title: "OTP Sent",
        description: "Please check your email/phone for the verification code.",
      });
      setLocation('/otp-verification');
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to send OTP",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!emailOrPhone.trim()) {
      toast({
        title: "Error",
        description: "Please enter your email or phone number",
        variant: "destructive",
      });
      return;
    }
    sendOTPMutation.mutate({ emailOrPhone });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 flex flex-col">
      <div className="flex-1 flex flex-col justify-center px-6">
        <div className="text-center mb-8">
          <i className="fas fa-tasks text-5xl text-primary-blue mb-4"></i>
          <h2 className="text-2xl font-bold text-gray-800 mb-2" data-testid="welcome-title">
            Welcome to TasksIQ
          </h2>
          <p className="text-gray-600" data-testid="login-subtitle">
            Enter your credentials to continue
          </p>
        </div>

        <Card className="bg-white rounded-2xl shadow-lg">
          <CardContent className="p-6">
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  <i className="fas fa-envelope mr-2"></i>
                  Email or Mobile Number
                </label>
                <Input
                  type="text"
                  placeholder="Enter email or mobile"
                  value={emailOrPhone}
                  onChange={(e) => setEmailOrPhone(e.target.value)}
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-primary-blue focus:border-transparent"
                  data-testid="input-email-phone"
                />
              </div>
              
              <Button
                type="submit"
                disabled={sendOTPMutation.isPending}
                className="w-full bg-accent-orange text-white py-3 rounded-xl font-semibold hover:bg-orange-600 transition-colors"
                data-testid="button-send-otp"
              >
                {sendOTPMutation.isPending ? "Sending..." : "Send OTP"}
              </Button>

              <div className="text-center">
                <a href="#" className="text-sm text-primary-blue hover:underline" data-testid="link-support">
                  Need help? Contact Support
                </a>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
