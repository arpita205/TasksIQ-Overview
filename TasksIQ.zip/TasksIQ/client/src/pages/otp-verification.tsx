import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { useAuthStore } from "@/lib/auth";
import { apiRequest } from "@/lib/queryClient";

export default function OTPVerification() {
  const [otp, setOtp] = useState(["", "", "", "", "", ""]);
  const [timeLeft, setTimeLeft] = useState(150); // 2:30 minutes
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const { tempEmail, setOTPVerified } = useAuthStore();

  useEffect(() => {
    if (!tempEmail) {
      setLocation('/login');
      return;
    }

    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [tempEmail, setLocation]);

  const verifyOTPMutation = useMutation({
    mutationFn: async (data: { emailOrPhone: string; otp: string }) => {
      const response = await apiRequest("POST", "/api/auth/verify-otp", data);
      return response.json();
    },
    onSuccess: () => {
      setOTPVerified(true);
      toast({
        title: "OTP Verified",
        description: "Verification successful!",
      });
      setLocation('/role-selection');
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Invalid OTP",
        variant: "destructive",
      });
    },
  });

  const handleOTPChange = (index: number, value: string) => {
    if (value.length > 1) return;
    
    const newOtp = [...otp];
    newOtp[index] = value;
    setOtp(newOtp);

    // Auto-focus next input
    if (value && index < 5) {
      const nextInput = document.querySelector(`[data-testid="otp-input-${index + 1}"]`) as HTMLInputElement;
      nextInput?.focus();
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const otpString = otp.join("");
    if (otpString.length !== 6) {
      toast({
        title: "Error",
        description: "Please enter complete OTP",
        variant: "destructive",
      });
      return;
    }
    verifyOTPMutation.mutate({ emailOrPhone: tempEmail, otp: otpString });
  };

  const formatTime = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 flex flex-col">
      <div className="flex-1 flex flex-col justify-center px-6">
        <div className="text-center mb-8">
          <i className="fas fa-shield-alt text-5xl text-primary-blue mb-4"></i>
          <h2 className="text-2xl font-bold text-gray-800 mb-2" data-testid="verify-title">
            Verify OTP
          </h2>
          <p className="text-gray-600" data-testid="verify-subtitle">
            Enter the 6-digit code sent to your device
          </p>
        </div>

        <Card className="bg-white rounded-2xl shadow-lg">
          <CardContent className="p-6">
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="flex justify-center items-center space-x-3">
                {otp.map((digit, index) => (
                  <input
                    key={index}
                    type="text"
                    maxLength={1}
                    value={digit}
                    onChange={(e) => handleOTPChange(index, e.target.value)}
                    className="w-12 h-12 text-center text-xl font-bold border-2 border-gray-300 rounded-lg focus:border-primary-blue outline-none"
                    data-testid={`otp-input-${index}`}
                  />
                ))}
              </div>

              <div className="text-center">
                <div className="text-sm text-gray-600 mb-4">
                  <i className="fas fa-clock mr-1"></i>
                  <span data-testid="timer">{formatTime(timeLeft)}</span>
                </div>
              </div>
              
              <Button
                type="submit"
                disabled={verifyOTPMutation.isPending}
                className="w-full bg-accent-orange text-white py-3 rounded-xl font-semibold hover:bg-orange-600 transition-colors"
                data-testid="button-verify-otp"
              >
                {verifyOTPMutation.isPending ? "Verifying..." : "Verify & Continue"}
              </Button>

              <div className="text-center">
                <button
                  type="button"
                  className="text-sm text-primary-blue hover:underline"
                  data-testid="button-resend-otp"
                >
                  Resend OTP
                </button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
