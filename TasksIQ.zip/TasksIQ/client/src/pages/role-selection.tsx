import { useLocation } from "wouter";
import { useMutation } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { useAuthStore } from "@/lib/auth";
import { apiRequest } from "@/lib/queryClient";

export default function RoleSelection() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const { tempEmail, isOTPVerified, setUser } = useAuthStore();

  const registerMutation = useMutation({
    mutationFn: async (data: { email: string; name: string; role: string }) => {
      const response = await apiRequest("POST", "/api/auth/register", data);
      return response.json();
    },
    onSuccess: (data) => {
      setUser(data.user);
      toast({
        title: "Registration Successful",
        description: "Welcome to TasksIQ!",
      });
      
      if (data.user.role === 'admin') {
        setLocation('/admin-dashboard');
      } else {
        setLocation('/team-dashboard');
      }
    },
    onError: (error: any) => {
      // If user already exists, try login
      if (error.message?.includes("already exists")) {
        loginMutation.mutate({ email: tempEmail });
      } else {
        toast({
          title: "Error",
          description: error.message || "Registration failed",
          variant: "destructive",
        });
      }
    },
  });

  const loginMutation = useMutation({
    mutationFn: async (data: { email: string }) => {
      const response = await apiRequest("POST", "/api/auth/login", data);
      return response.json();
    },
    onSuccess: (data) => {
      setUser(data.user);
      toast({
        title: "Login Successful",
        description: "Welcome back to TasksIQ!",
      });
      
      if (data.user.role === 'admin') {
        setLocation('/admin-dashboard');
      } else {
        setLocation('/team-dashboard');
      }
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Login failed",
        variant: "destructive",
      });
    },
  });

  if (!isOTPVerified || !tempEmail) {
    setLocation('/login');
    return null;
  }

  const handleRoleSelect = (role: 'admin' | 'team_member') => {
    const name = role === 'admin' ? 'Arpita Sharma' : 'Team Member';
    registerMutation.mutate({
      email: tempEmail,
      name,
      role,
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 flex flex-col">
      <div className="flex-1 flex flex-col justify-center px-6">
        <div className="text-center mb-8">
          <h2 className="text-2xl font-bold text-gray-800 mb-2" data-testid="role-selection-title">
            Choose Your Role
          </h2>
          <p className="text-gray-600" data-testid="role-selection-subtitle">
            Select how you'll be using TasksIQ
          </p>
        </div>

        <div className="space-y-4">
          <Card 
            className="cursor-pointer hover:border-primary-blue transition-all border-2 border-transparent"
            onClick={() => handleRoleSelect('admin')}
            data-testid="card-admin-role"
          >
            <CardContent className="p-6">
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-primary-blue rounded-xl flex items-center justify-center">
                  <i className="fas fa-crown text-white text-xl"></i>
                </div>
                <div className="text-left">
                  <h3 className="font-semibold text-gray-800" data-testid="text-admin-title">Admin</h3>
                  <p className="text-sm text-gray-600" data-testid="text-admin-description">
                    Manage projects, assign tasks, and lead teams
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card 
            className="cursor-pointer hover:border-primary-green transition-all border-2 border-transparent"
            onClick={() => handleRoleSelect('team_member')}
            data-testid="card-team-role"
          >
            <CardContent className="p-6">
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-primary-green rounded-xl flex items-center justify-center">
                  <i className="fas fa-users text-white text-xl"></i>
                </div>
                <div className="text-left">
                  <h3 className="font-semibold text-gray-800" data-testid="text-team-title">Team Member</h3>
                  <p className="text-sm text-gray-600" data-testid="text-team-description">
                    Receive tasks and collaborate with your team
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
