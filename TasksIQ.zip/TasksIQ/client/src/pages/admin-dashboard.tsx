import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useAuthStore } from "@/lib/auth";
import { useLocation } from "wouter";
import BottomNavigation from "@/components/bottom-navigation";
import CreateTaskModal from "@/components/create-task-modal";
import type { DashboardStats } from "@/types";

export default function AdminDashboard() {
  const [showCreateTask, setShowCreateTask] = useState(false);
  const [, setLocation] = useLocation();
  const { user } = useAuthStore();

  if (!user || user.role !== 'admin') {
    setLocation('/login');
    return null;
  }

  const { data: stats } = useQuery<DashboardStats>({
    queryKey: ['/api/dashboard/stats'],
    queryFn: async () => {
      const response = await fetch(`/api/dashboard/stats?userId=${user.id}&role=${user.role}`);
      return response.json();
    },
  });

  const { data: notifications } = useQuery({
    queryKey: ['/api/notifications'],
    queryFn: async () => {
      const response = await fetch(`/api/notifications?userId=${user.id}`);
      return response.json();
    },
  });

  const unreadCount = notifications?.filter((n: any) => !n.isRead).length || 0;

  return (
    <>
      <div className="min-h-screen bg-gray-50 pb-20">
        {/* Header */}
        <div className="bg-gradient-admin px-6 py-6 text-white">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-white/20 rounded-full flex items-center justify-center">
                <span className="font-semibold" data-testid="text-user-initials">
                  {user.name.split(' ').map(n => n[0]).join('')}
                </span>
              </div>
              <div>
                <h1 className="text-lg font-semibold" data-testid="text-greeting">
                  👋 Hello {user.name.split(' ')[0]},
                </h1>
                <p className="text-sm opacity-90" data-testid="text-greeting-subtitle">
                  Ready to lead today?
                </p>
              </div>
            </div>
            <div className="relative">
              <button 
                className="relative p-2"
                data-testid="button-notifications"
              >
                <i className="fas fa-bell text-xl"></i>
                {unreadCount > 0 && (
                  <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full text-xs flex items-center justify-center">
                    {unreadCount}
                  </span>
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Dashboard Cards */}
        <div className="px-6 py-6 space-y-4">
          {/* Projects Card */}
          <Card className="bg-white rounded-2xl shadow-lg">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-blue-100 rounded-xl flex items-center justify-center">
                    <i className="fas fa-folder text-primary-blue"></i>
                  </div>
                  <h3 className="font-semibold text-gray-800" data-testid="text-projects-title">Projects</h3>
                </div>
                <Button
                  size="sm"
                  className="w-8 h-8 bg-primary-blue rounded-full flex items-center justify-center"
                  data-testid="button-add-project"
                >
                  <i className="fas fa-plus text-white text-sm"></i>
                </Button>
              </div>
              <div className="text-2xl font-bold text-gray-800 mb-2" data-testid="text-project-count">
                {stats?.projectCount || 0}
              </div>
              <p className="text-sm text-gray-600">Active projects</p>
            </CardContent>
          </Card>

          {/* Team Members Card */}
          <Card className="bg-white rounded-2xl shadow-lg">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-green-100 rounded-xl flex items-center justify-center">
                    <i className="fas fa-users text-primary-green"></i>
                  </div>
                  <h3 className="font-semibold text-gray-800" data-testid="text-team-title">Team Members</h3>
                </div>
                <Button
                  size="sm"
                  className="px-3 py-1 bg-primary-green text-white text-sm rounded-lg"
                  data-testid="button-invite-team"
                >
                  Invite
                </Button>
              </div>
              <div className="text-2xl font-bold text-gray-800 mb-2" data-testid="text-team-count">
                12
              </div>
              <p className="text-sm text-gray-600">Active members</p>
            </CardContent>
          </Card>

          {/* Tasks Overview Card */}
          <Card className="bg-white rounded-2xl shadow-lg">
            <CardContent className="p-6">
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-10 h-10 bg-orange-100 rounded-xl flex items-center justify-center">
                  <i className="fas fa-tasks text-accent-orange"></i>
                </div>
                <h3 className="font-semibold text-gray-800" data-testid="text-tasks-overview-title">Tasks Overview</h3>
              </div>
              
              <div className="grid grid-cols-3 gap-4">
                <div className="text-center">
                  <div className="text-lg font-bold text-status-pending" data-testid="text-tasks-pending">
                    {stats?.taskStats.pending || 0}
                  </div>
                  <div className="text-xs text-gray-600">Pending</div>
                </div>
                <div className="text-center">
                  <div className="text-lg font-bold text-status-progress" data-testid="text-tasks-progress">
                    {stats?.taskStats.progress || 0}
                  </div>
                  <div className="text-xs text-gray-600">In Progress</div>
                </div>
                <div className="text-center">
                  <div className="text-lg font-bold text-status-completed" data-testid="text-tasks-completed">
                    {stats?.taskStats.completed || 0}
                  </div>
                  <div className="text-xs text-gray-600">Completed</div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Quick Actions */}
          <Card className="bg-white rounded-2xl shadow-lg">
            <CardContent className="p-6">
              <h3 className="font-semibold text-gray-800 mb-4" data-testid="text-quick-actions-title">Quick Actions</h3>
              <div className="grid grid-cols-2 gap-3">
                <button
                  onClick={() => setShowCreateTask(true)}
                  className="flex flex-col items-center space-y-2 p-4 bg-blue-50 rounded-xl hover:bg-blue-100 transition-colors"
                  data-testid="button-create-task"
                >
                  <i className="fas fa-plus-circle text-primary-blue text-xl"></i>
                  <span className="text-sm font-medium text-gray-700">Create Task</span>
                </button>
                <button className="flex flex-col items-center space-y-2 p-4 bg-green-50 rounded-xl hover:bg-green-100 transition-colors"
                  data-testid="button-view-projects"
                >
                  <i className="fas fa-eye text-primary-green text-xl"></i>
                  <span className="text-sm font-medium text-gray-700">View Projects</span>
                </button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Floating Action Button */}
        <button
          onClick={() => setShowCreateTask(true)}
          className="fixed bottom-20 right-6 w-14 h-14 bg-accent-orange text-white rounded-full shadow-lg flex items-center justify-center hover:bg-orange-600 transition-all transform hover:scale-105 z-40"
          data-testid="fab-create-task"
        >
          <i className="fas fa-plus text-xl"></i>
        </button>
      </div>

      <BottomNavigation userRole="admin" />
      
      {showCreateTask && (
        <CreateTaskModal 
          isOpen={showCreateTask} 
          onClose={() => setShowCreateTask(false)} 
        />
      )}
    </>
  );
}
