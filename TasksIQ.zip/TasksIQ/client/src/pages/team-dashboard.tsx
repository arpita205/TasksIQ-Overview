import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { useAuthStore } from "@/lib/auth";
import { useLocation } from "wouter";
import BottomNavigation from "@/components/bottom-navigation";
import TaskCard from "@/components/task-card";
import type { DashboardStats, TaskWithDetails } from "@/types";

export default function TeamDashboard() {
  const [, setLocation] = useLocation();
  const { user } = useAuthStore();

  if (!user || user.role !== 'team_member') {
    setLocation('/login');
    return null;
  }

  const { data: stats } = useQuery<DashboardStats>({
    queryKey: ['/api/dashboard/stats'],
    queryFn: async () => {
      const response = await fetch(`/api/dashboard/stats?userId=${user.id}&role=${user.role}`);
      return response.json();
    },
  });

  const { data: tasks = [] } = useQuery<TaskWithDetails[]>({
    queryKey: ['/api/tasks'],
    queryFn: async () => {
      const response = await fetch(`/api/tasks?userId=${user.id}`);
      return response.json();
    },
  });

  const { data: notifications } = useQuery({
    queryKey: ['/api/notifications'],
    queryFn: async () => {
      const response = await fetch(`/api/notifications?userId=${user.id}`);
      return response.json();
    },
  });

  const unreadCount = notifications?.filter((n: any) => !n.isRead).length || 0;

  return (
    <>
      <div className="min-h-screen bg-gray-50 pb-20">
        {/* Header */}
        <div className="bg-gradient-team px-6 py-6 text-white">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h1 className="text-lg font-semibold" data-testid="text-tasks-today">🎯 Your Tasks Today</h1>
              <p className="text-sm opacity-90" data-testid="text-current-date">
                {new Date().toLocaleDateString('en-US', { 
                  weekday: 'long', 
                  year: 'numeric', 
                  month: 'short', 
                  day: 'numeric' 
                })}
              </p>
            </div>
            <div className="relative">
              <button className="relative p-2" data-testid="button-notifications">
                <i className="fas fa-bell text-xl"></i>
                {unreadCount > 0 && (
                  <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full text-xs flex items-center justify-center">
                    {unreadCount}
                  </span>
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Task Stats */}
        <div className="px-6 py-4">
          <div className="grid grid-cols-4 gap-3">
            <Card className="rounded-xl shadow-sm">
              <CardContent className="p-3 text-center">
                <div className="text-lg font-bold text-status-pending" data-testid="text-my-tasks-pending">
                  {stats?.taskStats.pending || 0}
                </div>
                <div className="text-xs text-gray-600">Pending</div>
              </CardContent>
            </Card>
            <Card className="rounded-xl shadow-sm">
              <CardContent className="p-3 text-center">
                <div className="text-lg font-bold text-status-progress" data-testid="text-my-tasks-progress">
                  {stats?.taskStats.progress || 0}
                </div>
                <div className="text-xs text-gray-600">In Progress</div>
              </CardContent>
            </Card>
            <Card className="rounded-xl shadow-sm">
              <CardContent className="p-3 text-center">
                <div className="text-lg font-bold text-status-completed" data-testid="text-my-tasks-completed">
                  {stats?.taskStats.completed || 0}
                </div>
                <div className="text-xs text-gray-600">Completed</div>
              </CardContent>
            </Card>
            <Card className="rounded-xl shadow-sm">
              <CardContent className="p-3 text-center">
                <div className="text-lg font-bold text-status-cancelled" data-testid="text-my-tasks-cancelled">
                  {stats?.taskStats.cancelled || 0}
                </div>
                <div className="text-xs text-gray-600">Cancelled</div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Task List */}
        <div className="px-6 pb-6 space-y-4">
          {tasks.length === 0 ? (
            <Card className="bg-white rounded-2xl shadow-lg">
              <CardContent className="p-6 text-center">
                <i className="fas fa-tasks text-4xl text-gray-300 mb-4"></i>
                <h3 className="text-lg font-semibold text-gray-600 mb-2">No Tasks Yet</h3>
                <p className="text-gray-500">You don't have any tasks assigned yet.</p>
              </CardContent>
            </Card>
          ) : (
            tasks.map((task) => (
              <TaskCard key={task.id} task={task} />
            ))
          )}

          {/* Motivational Quote */}
          <Card className="bg-gradient-motivational rounded-2xl text-white">
            <CardContent className="p-6 text-center">
              <i className="fas fa-quote-left text-2xl mb-3 opacity-80"></i>
              <p className="font-medium mb-2" data-testid="text-motivational-quote">
                "Small progress each day adds up to big results."
              </p>
              <p className="text-sm opacity-80" data-testid="text-motivational-subtitle">
                Keep going! You're doing great 🌟
              </p>
            </CardContent>
          </Card>
        </div>
      </div>

      <BottomNavigation userRole="team_member" />
    </>
  );
}
