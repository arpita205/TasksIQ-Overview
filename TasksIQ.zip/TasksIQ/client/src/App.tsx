import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import SplashScreen from "@/pages/splash";
import LoginScreen from "@/pages/login";
import OTPVerification from "@/pages/otp-verification";
import RoleSelection from "@/pages/role-selection";
import AdminDashboard from "@/pages/admin-dashboard";
import TeamDashboard from "@/pages/team-dashboard";
import ProfileScreen from "@/pages/profile";

function Router() {
  return (
    <Switch>
      <Route path="/" component={SplashScreen} />
      <Route path="/login" component={LoginScreen} />
      <Route path="/otp-verification" component={OTPVerification} />
      <Route path="/role-selection" component={RoleSelection} />
      <Route path="/admin-dashboard" component={AdminDashboard} />
      <Route path="/team-dashboard" component={TeamDashboard} />
      <Route path="/profile" component={ProfileScreen} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <div className="mobile-container">
          <Toaster />
          <Router />
        </div>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
