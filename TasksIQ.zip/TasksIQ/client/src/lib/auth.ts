import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { User } from '@shared/schema';

interface AuthState {
  user: User | null;
  tempEmail: string;
  isOTPVerified: boolean;
  setUser: (user: User | null) => void;
  setTempEmail: (email: string) => void;
  setOTPVerified: (verified: boolean) => void;
  logout: () => void;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      user: null,
      tempEmail: '',
      isOTPVerified: false,
      setUser: (user) => set({ user }),
      setTempEmail: (email) => set({ tempEmail: email }),
      setOTPVerified: (verified) => set({ isOTPVerified: verified }),
      logout: () => set({ user: null, tempEmail: '', isOTPVerified: false }),
    }),
    {
      name: 'auth-storage',
    }
  )
);
