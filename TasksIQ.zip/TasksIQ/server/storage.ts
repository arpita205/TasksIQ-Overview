import { 
  type User, 
  type InsertUser, 
  type Project, 
  type InsertProject,
  type Task,
  type InsertTask,
  type TaskComment,
  type InsertTaskComment,
  type TeamMember,
  type InsertTeamMember,
  type Notification,
  type InsertNotification,
  type TaskWithDetails,
  type ProjectWithMembers
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Users
  getUser(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, updates: Partial<User>): Promise<User | undefined>;
  
  // Projects
  getProject(id: string): Promise<Project | undefined>;
  getProjectsByAdmin(adminId: string): Promise<Project[]>;
  getProjectsWithMembers(adminId: string): Promise<ProjectWithMembers[]>;
  createProject(project: InsertProject): Promise<Project>;
  
  // Tasks
  getTask(id: string): Promise<Task | undefined>;
  getTaskWithDetails(id: string): Promise<TaskWithDetails | undefined>;
  getTasksByUser(userId: string): Promise<TaskWithDetails[]>;
  getTasksByAssigner(assignerId: string): Promise<TaskWithDetails[]>;
  createTask(task: InsertTask): Promise<Task>;
  updateTask(id: string, updates: Partial<Task>): Promise<Task | undefined>;
  
  // Task Comments
  getTaskComments(taskId: string): Promise<TaskComment[]>;
  addTaskComment(comment: InsertTaskComment): Promise<TaskComment>;
  
  // Team Members
  getTeamMembersByProject(projectId: string): Promise<(TeamMember & { user: User })[]>;
  getTeamMembersByUser(userId: string): Promise<TeamMember[]>;
  addTeamMember(member: InsertTeamMember): Promise<TeamMember>;
  updateTeamMember(id: string, updates: Partial<TeamMember>): Promise<TeamMember | undefined>;
  
  // Notifications
  getNotificationsByUser(userId: string): Promise<Notification[]>;
  createNotification(notification: InsertNotification): Promise<Notification>;
  markNotificationRead(id: string): Promise<void>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User> = new Map();
  private projects: Map<string, Project> = new Map();
  private tasks: Map<string, Task> = new Map();
  private taskComments: Map<string, TaskComment> = new Map();
  private teamMembers: Map<string, TeamMember> = new Map();
  private notifications: Map<string, Notification> = new Map();

  constructor() {
    this.seedData();
  }

  private seedData() {
    // Create admin user
    const adminUser: User = {
      id: "admin-1",
      email: "admin@tasksiq.com",
      phone: "+91 9876543210",
      name: "Arpita Sharma",
      role: "admin",
      isVerified: true,
      createdAt: new Date(),
    };
    this.users.set(adminUser.id, adminUser);

    // Create team members
    const teamUser1: User = {
      id: "user-1",
      email: "rahul@company.com",
      phone: "+91 9876543211",
      name: "Rahul Sharma",
      role: "team_member",
      isVerified: true,
      createdAt: new Date(),
    };
    this.users.set(teamUser1.id, teamUser1);

    const teamUser2: User = {
      id: "user-2",
      email: "priya@company.com",
      phone: "+91 9876543212",
      name: "Priya Patel",
      role: "team_member",
      isVerified: true,
      createdAt: new Date(),
    };
    this.users.set(teamUser2.id, teamUser2);

    // Create project
    const project: Project = {
      id: "project-1",
      name: "TasksIQ Development",
      description: "Main development project for TasksIQ application",
      adminId: adminUser.id,
      createdAt: new Date(),
    };
    this.projects.set(project.id, project);

    // Create team memberships
    const member1: TeamMember = {
      id: "member-1",
      projectId: project.id,
      userId: teamUser1.id,
      invitedById: adminUser.id,
      status: "active",
      joinedAt: new Date(),
      createdAt: new Date(),
    };
    this.teamMembers.set(member1.id, member1);

    const member2: TeamMember = {
      id: "member-2",
      projectId: project.id,
      userId: teamUser2.id,
      invitedById: adminUser.id,
      status: "active",
      joinedAt: new Date(),
      createdAt: new Date(),
    };
    this.teamMembers.set(member2.id, member2);

    // Create sample tasks
    const task1: Task = {
      id: "task-1",
      title: "Submit Weekly Report",
      description: "Prepare and submit the weekly progress report for the development team",
      projectId: project.id,
      assignedById: adminUser.id,
      assignedToId: teamUser1.id,
      status: "pending",
      dueDate: new Date(Date.now() + 6 * 60 * 60 * 1000), // 6 hours from now
      acceptedAt: null,
      completedAt: null,
      createdAt: new Date(),
    };
    this.tasks.set(task1.id, task1);

    const task2: Task = {
      id: "task-2",
      title: "Review API Documentation",
      description: "Review and update the API documentation for version 2.0",
      projectId: project.id,
      assignedById: adminUser.id,
      assignedToId: teamUser1.id,
      status: "in_progress",
      dueDate: new Date(Date.now() + 24 * 60 * 60 * 1000), // 24 hours from now
      acceptedAt: new Date(Date.now() - 2 * 60 * 60 * 1000),
      completedAt: null,
      createdAt: new Date(Date.now() - 3 * 60 * 60 * 1000),
    };
    this.tasks.set(task2.id, task2);
  }

  // Users
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.email === email);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { 
      ...insertUser, 
      id,
      createdAt: new Date(),
    };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: string, updates: Partial<User>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...updates };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  // Projects
  async getProject(id: string): Promise<Project | undefined> {
    return this.projects.get(id);
  }

  async getProjectsByAdmin(adminId: string): Promise<Project[]> {
    return Array.from(this.projects.values()).filter(project => project.adminId === adminId);
  }

  async getProjectsWithMembers(adminId: string): Promise<ProjectWithMembers[]> {
    const projects = await this.getProjectsByAdmin(adminId);
    const result: ProjectWithMembers[] = [];

    for (const project of projects) {
      const admin = await this.getUser(project.adminId);
      const members = await this.getTeamMembersByProject(project.id);
      const projectTasks = Array.from(this.tasks.values()).filter(task => task.projectId === project.id);
      
      if (admin) {
        result.push({
          ...project,
          admin,
          members,
          taskCount: projectTasks.length,
        });
      }
    }

    return result;
  }

  async createProject(insertProject: InsertProject): Promise<Project> {
    const id = randomUUID();
    const project: Project = { 
      ...insertProject, 
      id,
      createdAt: new Date(),
    };
    this.projects.set(id, project);
    return project;
  }

  // Tasks
  async getTask(id: string): Promise<Task | undefined> {
    return this.tasks.get(id);
  }

  async getTaskWithDetails(id: string): Promise<TaskWithDetails | undefined> {
    const task = this.tasks.get(id);
    if (!task) return undefined;

    const assignedBy = await this.getUser(task.assignedById);
    const assignedTo = await this.getUser(task.assignedToId);
    const project = task.projectId ? await this.getProject(task.projectId) : undefined;
    const comments = await this.getTaskComments(task.id);

    if (!assignedBy || !assignedTo) return undefined;

    return {
      ...task,
      assignedBy,
      assignedTo,
      project,
      comments,
    };
  }

  async getTasksByUser(userId: string): Promise<TaskWithDetails[]> {
    const userTasks = Array.from(this.tasks.values()).filter(task => task.assignedToId === userId);
    const result: TaskWithDetails[] = [];

    for (const task of userTasks) {
      const taskWithDetails = await this.getTaskWithDetails(task.id);
      if (taskWithDetails) {
        result.push(taskWithDetails);
      }
    }

    return result.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  async getTasksByAssigner(assignerId: string): Promise<TaskWithDetails[]> {
    const assignedTasks = Array.from(this.tasks.values()).filter(task => task.assignedById === assignerId);
    const result: TaskWithDetails[] = [];

    for (const task of assignedTasks) {
      const taskWithDetails = await this.getTaskWithDetails(task.id);
      if (taskWithDetails) {
        result.push(taskWithDetails);
      }
    }

    return result.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  async createTask(insertTask: InsertTask): Promise<Task> {
    const id = randomUUID();
    const task: Task = { 
      ...insertTask, 
      id,
      acceptedAt: null,
      completedAt: null,
      createdAt: new Date(),
    };
    this.tasks.set(id, task);
    return task;
  }

  async updateTask(id: string, updates: Partial<Task>): Promise<Task | undefined> {
    const task = this.tasks.get(id);
    if (!task) return undefined;
    
    const updatedTask = { ...task, ...updates };
    this.tasks.set(id, updatedTask);
    return updatedTask;
  }

  // Task Comments
  async getTaskComments(taskId: string): Promise<TaskComment[]> {
    return Array.from(this.taskComments.values())
      .filter(comment => comment.taskId === taskId)
      .sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
  }

  async addTaskComment(insertComment: InsertTaskComment): Promise<TaskComment> {
    const id = randomUUID();
    const comment: TaskComment = { 
      ...insertComment, 
      id,
      createdAt: new Date(),
    };
    this.taskComments.set(id, comment);
    return comment;
  }

  // Team Members
  async getTeamMembersByProject(projectId: string): Promise<(TeamMember & { user: User })[]> {
    const members = Array.from(this.teamMembers.values()).filter(member => member.projectId === projectId);
    const result: (TeamMember & { user: User })[] = [];

    for (const member of members) {
      const user = await this.getUser(member.userId);
      if (user) {
        result.push({ ...member, user });
      }
    }

    return result;
  }

  async getTeamMembersByUser(userId: string): Promise<TeamMember[]> {
    return Array.from(this.teamMembers.values()).filter(member => member.userId === userId);
  }

  async addTeamMember(insertMember: InsertTeamMember): Promise<TeamMember> {
    const id = randomUUID();
    const member: TeamMember = { 
      ...insertMember, 
      id,
      joinedAt: null,
      createdAt: new Date(),
    };
    this.teamMembers.set(id, member);
    return member;
  }

  async updateTeamMember(id: string, updates: Partial<TeamMember>): Promise<TeamMember | undefined> {
    const member = this.teamMembers.get(id);
    if (!member) return undefined;
    
    const updatedMember = { ...member, ...updates };
    this.teamMembers.set(id, updatedMember);
    return updatedMember;
  }

  // Notifications
  async getNotificationsByUser(userId: string): Promise<Notification[]> {
    return Array.from(this.notifications.values())
      .filter(notification => notification.userId === userId)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  async createNotification(insertNotification: InsertNotification): Promise<Notification> {
    const id = randomUUID();
    const notification: Notification = { 
      ...insertNotification, 
      id,
      createdAt: new Date(),
    };
    this.notifications.set(id, notification);
    return notification;
  }

  async markNotificationRead(id: string): Promise<void> {
    const notification = this.notifications.get(id);
    if (notification) {
      notification.isRead = true;
      this.notifications.set(id, notification);
    }
  }
}

export const storage = new MemStorage();
