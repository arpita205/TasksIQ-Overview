import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertUserSchema, insertTaskSchema, insertProjectSchema, insertTaskCommentSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Authentication routes
  app.post("/api/auth/send-otp", async (req, res) => {
    const { emailOrPhone } = req.body;
    
    if (!emailOrPhone) {
      return res.status(400).json({ message: "Email or phone number is required" });
    }

    // Mock OTP sending - in real app, would send actual OTP
    res.json({ message: "OTP sent successfully", otp: "123456" });
  });

  app.post("/api/auth/verify-otp", async (req, res) => {
    const { emailOrPhone, otp } = req.body;
    
    if (!emailOrPhone || !otp) {
      return res.status(400).json({ message: "Email/phone and OTP are required" });
    }

    // Mock OTP verification
    if (otp !== "123456") {
      return res.status(400).json({ message: "Invalid OTP" });
    }

    res.json({ message: "OTP verified successfully", verified: true });
  });

  app.post("/api/auth/register", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      // Check if user already exists
      const existingUser = await storage.getUserByEmail(userData.email);
      if (existingUser) {
        return res.status(400).json({ message: "User already exists" });
      }

      const user = await storage.createUser(userData);
      res.json({ user });
    } catch (error) {
      res.status(400).json({ message: "Invalid user data", error });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    const { email } = req.body;
    
    if (!email) {
      return res.status(400).json({ message: "Email is required" });
    }

    const user = await storage.getUserByEmail(email);
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    res.json({ user });
  });

  // User routes
  app.get("/api/users/:id", async (req, res) => {
    const user = await storage.getUser(req.params.id);
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }
    res.json(user);
  });

  app.put("/api/users/:id", async (req, res) => {
    try {
      const updates = req.body;
      const user = await storage.updateUser(req.params.id, updates);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      res.json(user);
    } catch (error) {
      res.status(400).json({ message: "Invalid update data", error });
    }
  });

  // Project routes
  app.get("/api/projects", async (req, res) => {
    const { adminId } = req.query;
    if (!adminId || typeof adminId !== 'string') {
      return res.status(400).json({ message: "Admin ID is required" });
    }

    const projects = await storage.getProjectsWithMembers(adminId);
    res.json(projects);
  });

  app.post("/api/projects", async (req, res) => {
    try {
      const projectData = insertProjectSchema.parse(req.body);
      const project = await storage.createProject(projectData);
      res.json(project);
    } catch (error) {
      res.status(400).json({ message: "Invalid project data", error });
    }
  });

  // Task routes
  app.get("/api/tasks", async (req, res) => {
    const { userId, assignerId } = req.query;
    
    if (userId && typeof userId === 'string') {
      const tasks = await storage.getTasksByUser(userId);
      return res.json(tasks);
    }
    
    if (assignerId && typeof assignerId === 'string') {
      const tasks = await storage.getTasksByAssigner(assignerId);
      return res.json(tasks);
    }
    
    res.status(400).json({ message: "Either userId or assignerId is required" });
  });

  app.get("/api/tasks/:id", async (req, res) => {
    const task = await storage.getTaskWithDetails(req.params.id);
    if (!task) {
      return res.status(404).json({ message: "Task not found" });
    }
    res.json(task);
  });

  app.post("/api/tasks", async (req, res) => {
    try {
      const taskData = insertTaskSchema.parse(req.body);
      const task = await storage.createTask(taskData);
      
      // Create notification for assigned user
      await storage.createNotification({
        userId: task.assignedToId,
        type: "task_assigned",
        title: "New Task Assigned",
        message: `You have been assigned a new task: ${task.title}`,
        taskId: task.id,
        isRead: false,
      });

      res.json(task);
    } catch (error) {
      res.status(400).json({ message: "Invalid task data", error });
    }
  });

  app.put("/api/tasks/:id", async (req, res) => {
    try {
      const updates = req.body;
      
      // Handle status updates with timestamps
      if (updates.status === 'accepted') {
        updates.acceptedAt = new Date();
      } else if (updates.status === 'completed') {
        updates.completedAt = new Date();
      }

      const task = await storage.updateTask(req.params.id, updates);
      if (!task) {
        return res.status(404).json({ message: "Task not found" });
      }
      res.json(task);
    } catch (error) {
      res.status(400).json({ message: "Invalid update data", error });
    }
  });

  // Task comments
  app.get("/api/tasks/:id/comments", async (req, res) => {
    const comments = await storage.getTaskComments(req.params.id);
    res.json(comments);
  });

  app.post("/api/tasks/:id/comments", async (req, res) => {
    try {
      const commentData = {
        taskId: req.params.id,
        userId: req.body.userId,
        comment: req.body.comment,
      };
      
      const validatedData = insertTaskCommentSchema.parse(commentData);
      const comment = await storage.addTaskComment(validatedData);
      res.json(comment);
    } catch (error) {
      res.status(400).json({ message: "Invalid comment data", error });
    }
  });

  // Team member routes
  app.get("/api/projects/:id/members", async (req, res) => {
    const members = await storage.getTeamMembersByProject(req.params.id);
    res.json(members);
  });

  app.post("/api/team-members", async (req, res) => {
    try {
      const { projectId, email, invitedById } = req.body;
      
      // Find user by email
      const user = await storage.getUserByEmail(email);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      const member = await storage.addTeamMember({
        projectId,
        userId: user.id,
        invitedById,
        status: "invited",
      });

      // Create notification for invited user
      await storage.createNotification({
        userId: user.id,
        type: "team_invite",
        title: "Team Invitation",
        message: "You have been invited to join a project",
        isRead: false,
      });

      res.json(member);
    } catch (error) {
      res.status(400).json({ message: "Invalid team member data", error });
    }
  });

  // Notification routes
  app.get("/api/notifications", async (req, res) => {
    const { userId } = req.query;
    if (!userId || typeof userId !== 'string') {
      return res.status(400).json({ message: "User ID is required" });
    }

    const notifications = await storage.getNotificationsByUser(userId);
    res.json(notifications);
  });

  app.put("/api/notifications/:id/read", async (req, res) => {
    await storage.markNotificationRead(req.params.id);
    res.json({ message: "Notification marked as read" });
  });

  // Dashboard stats
  app.get("/api/dashboard/stats", async (req, res) => {
    const { userId, role } = req.query;
    
    if (!userId || !role || typeof userId !== 'string' || typeof role !== 'string') {
      return res.status(400).json({ message: "User ID and role are required" });
    }

    if (role === 'admin') {
      const projects = await storage.getProjectsByAdmin(userId);
      const tasks = await storage.getTasksByAssigner(userId);
      
      const taskStats = {
        pending: tasks.filter(t => t.status === 'pending').length,
        progress: tasks.filter(t => t.status === 'in_progress').length,
        completed: tasks.filter(t => t.status === 'completed').length,
        cancelled: tasks.filter(t => t.status === 'cancelled').length,
      };

      res.json({
        projectCount: projects.length,
        taskStats,
        totalTasks: tasks.length,
      });
    } else {
      const tasks = await storage.getTasksByUser(userId);
      
      const taskStats = {
        pending: tasks.filter(t => t.status === 'pending').length,
        progress: tasks.filter(t => t.status === 'in_progress').length,
        completed: tasks.filter(t => t.status === 'completed').length,
        cancelled: tasks.filter(t => t.status === 'cancelled').length,
      };

      res.json({ taskStats });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
